#include <iostream>
#include "console.h"
#include "SimpleTest.h"
#include "knapsack.h"  // run knapsack console program

using namespace std;

int main() {
    if (runSimpleTests(SELECTED_TESTS)) {
        return 0;
    }

    runKnapsack();

    return 0;
}
