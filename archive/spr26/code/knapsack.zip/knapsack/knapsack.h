#ifndef KNAPSACK_H
#define KNAPSACK_H

void runKnapsack();

#endif  // KNAPSACK_H
