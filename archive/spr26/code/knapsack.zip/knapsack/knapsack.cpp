// Name: Kevin Wang (he/him)
// File: knapsack.cpp
// ----------------------------
// Solves the knapsack problem! And implements a mini interactive
// console program, too, cuz why not?!

#include <iostream>
#include "SimpleTest.h"
#include "console.h"
#include "vector.h"
#include "simpio.h"
#include "strlib.h"
#include "knapsack.h"  // we'll need this to run the console program in main.cpp
using namespace std;

// define a backpack item! each item has two components:
// its survival value and its weight!
struct BackpackItem {
    int survivalValue;  // you can assume this value will always >= 0
    int weight;         // you can assume this value will always >= 0
};

// DON'T WORRY ABOUT THIS!
// this "function" overloads the printing operator << so that we can
// print out a BackpackItem if we wanted to! without it, C++ would
// be super confused...
ostream& operator<<(ostream& os, const BackpackItem& item) {
    os << "BackpackItem(survivalValue = " << item.survivalValue << ", weight = " << item.weight << ")";
    return os;
}

// fillBackpackDefault takes in four arguments:
//     - Vector<BackpackItem> &items
//     - int targetWeight
//     - int currentWeight
//     - int currentSurvivalValue
// and returns the maximum survival score given the list of backpack
// items, items. this recursive helper function for fillBackpack uses
// the classic choose, explore, unchoose strategy by removing the last element
// from a Vector _before_ the recursive calls, and then adds it back in to
// pretend like nothing ever happened. :-)
int fillBackpackDefault(Vector<BackpackItem> &items, int targetWeight, int currentWeight, int currentSurvivalValue) {
    // have we reached our target? return rn!
    if (currentWeight == targetWeight) {
        return currentSurvivalValue;
    }
    // uh oh...we've overfilled our bag and our items are spilling out!
    if (currentWeight > targetWeight) {
        // 0 is the lowest we can possible go! remember our assumptions...
        return 0;
    }
    // nothing in the bag? we can return what we have!
    else if (items.size() == 0) {
        return currentSurvivalValue;
    }

    // notice that we're taking the last item
    // let's examine the _last_ item _first_!
    // BackpackItem itemToExamine = items.remove(items.size() - 1);
    BackpackItem itemToExamine = items.remove(0);


    // what's the score with it?
    // (pay attention to the arguments!)
    int scoreWithItem   = fillBackpackDefault(items, targetWeight, currentWeight + itemToExamine.weight,
                                                                    currentSurvivalValue + itemToExamine.survivalValue);

    // what's the score _without_ it?
    // (pay attention to the difference in arguments!)
    int scoreWithoutItem = fillBackpackDefault(items, targetWeight, currentWeight,
                                                                    currentSurvivalValue);

    // let's add the item back
    // why does this matter? in future recursive calls, we have
    // to add the item back, othewise the list won't be in the
    // proper state
    // items.add(itemToExamine);
    items.insert(0, itemToExamine);

    // which is better? the score with the item, or without it?
    return max(scoreWithoutItem, scoreWithItem);

}

// fillBackpackIndexTrick takes in five (!) arguments:
//     - Vector<BackpackItem> &items
//     - int targetWeight
//     - int currentWeight
//     - int currentSurvivalValue
//     - int currentIndex
// and returns the maximum survival score given the list of backpack items,
// items. this recursive helper function for fillBackpack remixes
// the classic choose, explore, unchoose paradigm slightly by not removing
// any element from the Vector. instead, we keep track of where we are in the
// Vector via a passed-in argument currentIndex. in our use-it-or-lose-it paradigm,
// we simply traverse through the Vector, leaving it in-tact, but only looking at
// items[currentIndex]. this strategy _difers_ from the default approach since
// this approach examines the item at the _front_ of the Vector, while the
// default approach examines the item starting at the _back_ of the Vector.
int fillBackpackIndexTrick(Vector<BackpackItem> &items, int targetWeight, int currentWeight, int currentSurvivalValue, int currentIndex) {
    if (currentWeight > targetWeight) {
        return 0;
    }
    // vvvv NOTE THE CHANGE IN THIS BASE CASE! vvvv //
    // have we gone OOB? if so, return the survival value we currently have!
    else if (currentIndex == items.size()) {
        return currentSurvivalValue;
    }

    // notice that we're examining the *first item* first!
    // also notice that we're never removing or adding anything to the list!
    // much more efficient, right?
    BackpackItem itemToExamine = items[currentIndex];

    // what's the score with it?
    // (pay attention to the arguments!)
    int scoreWithItem    = fillBackpackIndexTrick(items, targetWeight, currentWeight + itemToExamine.weight,
                                                                       currentSurvivalValue + itemToExamine.survivalValue,
                                                                       currentIndex + 1);
    // what's the score _without_ it?
    // (pay attention to the difference in arguments!)
    int scoreWithoutItem = fillBackpackIndexTrick(items, targetWeight, currentWeight,
                                                                       currentSurvivalValue,
                                                                       currentIndex + 1);

    // which is better? the score with the item, or without it?
    return max(scoreWithoutItem, scoreWithItem);
}

// fillBackpackDefault takes in two arguments:
//     - Vector<BackpackItem> &items
//     - int targetWeight
// and returns the maximum survival score given the list of backpack items,
// items.
int fillBackpack(Vector<BackpackItem>& items, int targetWeight) {
    return fillBackpackDefault(items, targetWeight, 0, 0);
    // return fillBackpackIndexTrick(items, targetWeight, 0, 0, 0);
}

/////////////////////// CONSOLE PROGRAM I/O BELOW ////////////////////////

// getItems takes in no arguments and continues to prompt the user
// for each item's survival value and weight until the user hits
// RETURN, at which the loop breaks and the function returns
// the list of backpack items that the user entered in.
Vector<BackpackItem> getItems() {
    Vector<BackpackItem> items = {};

    while (true) {
        string data = getLine("Enter an item's stats: ");

        // did the user hit RETURN? if so, quit :')
        if (data == "") {
            break;
        }

        // everyone makes mistakes! offer another attempt if they accidentally hit enter after
        // typing in the next number
        if (data.size() == 1) {
            cout << "Oops! You only typed in one number. Try again!" << endl;
            continue;
        }

        Vector<string> stats = stringSplit(data, " ");

        // initialize the item
        BackpackItem item = { stringToInteger(stats[0]), stringToInteger(stats[1]) };
        //                    ^^^^^^^^^^^^^^^^^^^^^^^^^  ^^^^^^^^^^^^^^^^^^^^^^^^^
        //                               survival value                     weight

        items.add(item);
    }

    return items;
}

// getTargetWeight takes in no arguments and prompts the user for the max weight
// of their backpack. this function assumes that the user will only ever type in
// one and only one *number*. it's a helper function for runKnapsack!
int getTargetWeight() {
    return stringToInteger(getLine("\nEnter the max weight your backpack can hold: "));
}

// runKnapsack takes in no arguments and runs a console program, prompting
// the user to enter some items as well as the maximum weight of their (non)fictional
// bag, and then calls fillBackpack to print out the max survival value their
// bag can hold!
void runKnapsack() {
    //////////////////////////////////////////////////////////////////////////////////////
    cout << "\n\nHello, adventurer! Welcome to GREED ISLAND!" << endl;
    cout << "  =-=-=-=-=-=-=-=-= HXH =-=-=-=-=-=-=-=-=  " << endl;
    cout << "Enter your items in the following format: " << endl;
    cout << "       [survival value] [weight]" << endl;
    cout << "Once you've added enough items, press RETURN to quit." << endl << endl;
    //////////////////////////////////////////////////////////////////////////////////////

    // get input from the console...
    Vector<BackpackItem> items = getItems();
    int targetWeight = getTargetWeight();

    // ...and once we have the necessary data, calculate our max survival score!
    int score = fillBackpack(items, targetWeight);

    // now we show off how cool your backpack is! :D
    cout << "\nYour backpack can achieve a maximum of " << score << " survival points!" << endl;
}


PROVIDED_TEST("Simple knapsack examples.") {
    int targetWeight = 18;
    Vector<BackpackItem> items = {
        {12, 4},
        {10,6},
        {8, 5},
        {11, 7},
        {14, 3},
        {7, 1},
        {9, 6}
    };
    EXPECT_EQUAL(fillBackpack(items, targetWeight), 44);

    targetWeight = 25;
    items = {
       {5, 6},
       {20, 15},
       {3, 11},
       {50, 12},
       {5, 6},
       {4, 11},
       {15, 13},
       {12, 7},
       {6, 17},
       {7, 13}
    };

    EXPECT_EQUAL(fillBackpack(items, targetWeight), 67);

    targetWeight = 5;
    items = {
       {3, 2},
       {4, 3},
       {5, 4},
       {6, 5}
    };

    EXPECT_EQUAL(fillBackpack(items, targetWeight), 7);
}
